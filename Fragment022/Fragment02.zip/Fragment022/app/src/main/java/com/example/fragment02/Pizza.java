package com.example.fragment02;

public class Pizza {
    public static String[] pizzaMenu = {
            "Pizza cuatro quesos",
            "Pizza Napolitana",
            "Calzone"
    };

    public static String[] pizzaDetails = {
            "En la preparación tradicional se divide la pizza en cuatro partes,," +
                    " cada una con un tipo de queso como protagonista. Estos tienen " +
                    "que ser el queso mozzarella, el queso gorgonzola, el queso parmesano " +
                    "y el queso fontina. Sin embargo, también es común encontrar preparaciones " +
                    "con ricota, provolone o queso azul.",
            "Junto con la margarita, la pizza napolitana se sitúa como la segunda más tradicional de Italia. Una de las peculiaridades de esta pizza, también conocida como romana, es su masa: suave, esponjosa y algo más gruesa que la ortodoxa italiana, con los bordes más altos. Sus ingredientes, algo más valientes que los de la clásica margarita: salsa de tomate, queso mozzarella, anchoas, orégano, alcaparras y aceite de oliva..",
            "La calzone es una pizza especial por esconder en su interior todos sus ingredientes (queso, carne, atún, vegetales, etc.), ya que está cubierta por otra masa del mismo tamaño que la base, y en forma de empanadilla."
    };
}
